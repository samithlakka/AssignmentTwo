Samith Lakka
2352425
I referenced zybooks for parts of the problems.
