//This is the Header File Section
#include <iostream>
using namespace std;

//main function
int main() {

//declaration of the number array
int numberArray[10];

//inputting the 10 integers requested
cout << "Enter 10 integers for the array: ";

//this for loop reads up to ten nonnegative integers into an array
for (int i = 0; i < 10; ++i) {
cin >> numberArray[i];
}

//this for loop prints the number array
for (int i = 0; i < 10; ++i) {
cout << numberArray[i] << endl;
}
return 0;
}
