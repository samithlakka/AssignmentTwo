//This is the Header File Section
#include <iostream>
using namespace std;

//This void function declares two variables and sets the values to 0
void zero(int *varone,int *vartwo){
*varone=0;
*vartwo=0;
}

//main function
int main(){
//Declaration of variables
int varone;
int vartwo;
zero(&varone,&vartwo);

//print statements
cout<<varone<<endl;
cout<<vartwo<<endl;

return 0;

}
