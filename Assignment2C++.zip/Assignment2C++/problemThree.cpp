//This is the Header File Section
#include <iostream>
using namespace std;

//This function creates two parameters which include the tax rate and cost
void addTax(float taxRate, float *cost){
    float temp=*cost;
    temp+=(temp*taxrate)/100;
    *cost=temp;
    }
//main function
int main()
{
    cin >> tax;
    addTax(&t,10);
    cout<<"Cost with tax: "<<t;

    return 0;
}
