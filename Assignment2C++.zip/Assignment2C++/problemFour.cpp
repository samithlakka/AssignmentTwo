//This is the Header File Section
#include <cstdlib>
#include <iostream>
using namespace std;

//function skeleton for the converter
void convert(int,int);

//main function
int main(int argc, char *argv[])
{
//Declaration of variables
int feet;
int inches;

cout << "Enter number of feet: " << endl;
cin >> feet;
cout << "Enter number of inches: " << endl;
cin >> inches;

//calling the method above
convert(feet, inches);
system("wait");

//Exits the program
return EXIT_SUCCESS;
}
void convert(int feet, int inches)
{

//calculating the meters and centimeters
double meters=feet*0.3;
double centi = inches*2.54;


//printing the meters and centimeters
cout << "Meters: " << meters  << " and centimeters: " << centi << endl;

}
